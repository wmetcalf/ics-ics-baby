# ics-ics-baby

A single-binary Go CLI to parse `.ics` files, extract attachments, and render both:
- an **invite-style HTML** preview (like what email/web clients show)
- a **PNG screenshot** of that style using a pure-Go renderer (no browser)

This is a rename of the previous project to **ics-ics-baby** (module + binary).

## Build
```bash
cd ics-ics-baby
go mod tidy
go build ./cmd/ics-ics-baby
```

## Usage
```bash
./ics-ics-baby input.ics   --out out_dir   --html out_dir/preview.html   --screenshot out_dir/preview.png   --view invite \        # or agenda
  --download-attachments   --timezone America/Chicago   --start 2025-10-01   --end 2025-11-01   --style dark   --width 1200
```

### Outputs
- `out_dir/manifest.json` — parsed events + attachment details
- `out_dir/preview.html` — invite-style HTML
- `out_dir/preview.png` — pure-Go PNG (no browser)
- `out_dir/attachments/` — saved inline/downloaded files

### Notes
- VEVENT-focused parser (DTSTART/DTEND, TZID, VALUE=DATE, ORGANIZER, STATUS, ATTENDEE, ATTACH)
- Range filter uses DTSTART; end is exclusive.
- Recurrence expansion (RRULE/EXDATE) can be added later if you want.
- To vendor deps for offline builds:
  ```bash
  go mod vendor
  go build -mod=vendor ./cmd/ics-ics-baby
  ```
